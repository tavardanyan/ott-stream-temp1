export const mainConfig = {
    backUrl: 'https://panelapi.ottstream.live'
}